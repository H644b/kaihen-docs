kaiHEN developer documentation

Published at https://kaihen.timsfun.com
Research snapshot: November 13, 2026. Publication: November 14, 2026.

Guides preserve their source citations and verification scope. The templates are blank records for future development. No credentials, local device records or upstream binaries are included.
